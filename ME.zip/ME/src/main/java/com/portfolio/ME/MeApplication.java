package com.portfolio.ME;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeApplication.class, args);
	}

}
